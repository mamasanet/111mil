/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

/**
 *
 * @author María Isabel Masanet
 */
public class LaboreoCultivo {  
    
    /* atributos */
    private int id;
    private byte orden;
    private TipoLaboreo laboreo;
    private MomentoLaboreo momento;
    
    /* constructores    */
    public LaboreoCultivo(){}
    
    public LaboreoCultivo(byte orden){
        this.orden = orden;
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the orden
     */
    public byte getOrden() {
        return orden;
    }

    /**
     * @param orden the orden to set
     */
    public void setOrden(byte orden) {
        this.orden = orden;
    }

    /**
     * @return the laboreo
     */
    public TipoLaboreo getLaboreo() {
        return laboreo;
    }

    /**
     * @param laboreo the laboreo to set
     */
    public void setLaboreo(TipoLaboreo laboreo) {
        this.laboreo = laboreo;
    }

    /**
     * @return the momento
     */
    public MomentoLaboreo getMomento() {
        return momento;
    }

    /**
     * @param momento the momento to set
     */
    public void setMomento(MomentoLaboreo momento) {
        this.momento = momento;
    }
}
