/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

/**
 *
 * @author María Isabel Masanet 
 */
public class TipoLaboreo {
     /* atributos */
    private int id;
    private String labor;    

    /* constructor  */
    public TipoLaboreo(){}
    
    public TipoLaboreo(String labor){
        this.labor= labor;        
    }
    
    /**
     * @return the labor
     */
    public String getLabor() {
        return labor;
    }

    /**
     * @param labor the labor to set
     */
    public void setLabor(String labor) {
        this.labor = labor;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }    
}