/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class TipoSuelo {
    
     /* atributos */
    private int id;
    private String numero;
    private String descripcion;
    private List<Cultivo> cultivos;
    
    /* constructor    */
    public TipoSuelo(){}
    public TipoSuelo(String numero, String descripcion){
        this.numero = numero;
        this.descripcion = descripcion;
        this.cultivos = new ArrayList<>();
    }
    
    /**
     * @return the numero
     */
    public String getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the cultivos
     */
    public List<Cultivo> getCultivos() {
        return cultivos;
    }

    /**
     * @param cultivos the cultivos to set
     */
    public void setCultivos(List<Cultivo> cultivos) {
        this.cultivos = cultivos;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
