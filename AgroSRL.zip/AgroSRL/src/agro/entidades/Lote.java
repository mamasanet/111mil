/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class Lote {
   
    /* atributos */
    private int id;
    private byte numero;
    private float superficie;
    private TipoSuelo suelo;
    private List<Proyecto> proyectos;
    
    /* constructor*/
    public Lote(){}
    
    public Lote(byte numero, float superficie, TipoSuelo suelo){
        this.numero= numero;
        this.superficie= superficie;
        this.suelo = suelo;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    
    /**
     * @return the numero
     */
    public byte getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(byte numero) {
        this.numero = numero;
    }

    /**
     * @return the superficie
     */
    public float getSuperficie() {
        return superficie;
    }

    /**
     * @param superficie the superficie to set
     */
    public void setSuperficie(float superficie) {
        this.superficie = superficie;
    }
    
    /**
     * @return the suelo
     */
    public TipoSuelo getSuelo() {
        return suelo;
    }

    /**
     * @param suelo the suelo to set
     */
    public void setSuelo(TipoSuelo suelo) {
        this.suelo = suelo;
    }

    /**
     * @return the proyectos
     */
    public List<Proyecto> getProyectos() {
        return proyectos;
    }

    /**
     * @param proyectos the proyectos to set
     */
    public void setProyectos(List<Proyecto> proyectos) {
        this.proyectos = proyectos;
    }
}
