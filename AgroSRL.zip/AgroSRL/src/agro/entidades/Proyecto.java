/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

import java.util.Date;
import java.util.List;

/**
 *
 * @author María Isabel Masanet 
 */
public class Proyecto {
    
    private int id;
    private Date fechaInicio;
    private Date fechaFin;
    private EstadoProyecto estado;
    private Cultivo cultivo;
    private List<TipoLaboreo> laboreos;
    
    public Proyecto (){}
     
    public Proyecto (Date fechaInicio, Date fechaFin, EstadoProyecto estado, Cultivo cultivo){
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.cultivo = cultivo;
    }

    /**
     * @return the fechaInicio
     */
    public Date getFechaInicio() {
        return fechaInicio;
    }

    /**
     * @param fechaInicio the fechaInicio to set
     */
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * @return the fechaFin
     */
    public Date getFechaFin() {
        return fechaFin;
    }

    /**
     * @param fechaFin the fechaFin to set
     */
    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    /**
     * @return the estado
     */
    public EstadoProyecto getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(EstadoProyecto estado) {
        this.estado = estado;
    }

    /**
     * @return the cultivo
     */
    public Cultivo getCultivo() {
        return cultivo;
    }

    /**
     * @param cultivo the cultivo to set
     */
    public void setCultivo(Cultivo cultivo) {
        this.cultivo = cultivo;
    }

    /**
     * @return the laboreos
     */
    public List<TipoLaboreo> getLaboreos() {
        return laboreos;
    }

    /**
     * @param laboreos the laboreos to set
     */
    public void setLaboreos(List<TipoLaboreo> laboreos) {
        this.laboreos = laboreos;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
