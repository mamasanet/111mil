/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

import java.util.Iterator;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class Campo {   
    
    /** Atributos */
    private int id;
    private String nombre;
    private float superficie;
    private List<Lote> lotes;
    private EstadoCampo estado;
    
    /* Constructor */
     public Campo(){             
    }
    public Campo(String nombre, float superficie, List<Lote> lotes, EstadoCampo estado){
        this.nombre= nombre;
        this.superficie= superficie;
        this.lotes = lotes;
        this.estado = estado;
    } 
       
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    } 
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the superficie
     */
    public float getSuperficie() {
        return superficie;
    }

    /**
     * @param superficie the superficie to set
     */
    public void setSuperficie(float superficie) {
        this.superficie = superficie;
    }
    
    /**
     * @return the lotes
     */
    public List<Lote> getLotes() {
        return lotes;
    }

    /**
     * @param lotes the lotes to set
     */
    public void setLotes(List<Lote> lotes) {
        this.lotes = lotes;
    }
    
    /**
     * @return the estado
     */
    public EstadoCampo getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(EstadoCampo estado) {
        this.estado = estado;
    }
      
    /**
     * Este método suma la superficie de los lotes que conforman el campo.
     * No recibe parámetros
     * @return la suma de la superfice de los lotes
     */
    public float calculaSuperficieTotal(){
        float superficieTotal = 0;
        for(Lote lote : lotes)
            superficieTotal += lote.getSuperficie();        
        return superficieTotal;
    }
    
    /**
     * Busca un lote con el número pasado por parámetro
     * @param numero
     * @return el lote que posee el número del parámetro, si no lo encuentra retorna null
     */
    public  Lote buscarLote (byte numero){
        Lote retorno = null;
        Boolean encuentra = false;
        
        Iterator<Lote> iter = this.lotes.iterator();
        while (iter.hasNext() && !encuentra) {
            Lote lote = iter.next();
            
            if (lote.getNumero() == numero) {
                retorno = lote;
                encuentra = true;      
            }
        }
        return retorno;
    }  
}
