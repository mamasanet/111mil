/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

/**
 *
 * @author María Isabel Masanet
 */
public class MomentoLaboreo {
    
     /* atributos */
    private int id;
    private String momento;
    
    /* constructor  */
    public MomentoLaboreo(){} 
    
    public MomentoLaboreo(String momento){
        this.momento= momento;        
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the momento
     */
    public String getMomento() {
        return momento;
    }

    /**
     * @param momento the nombre to set
     */
    public void setMomento(String momento) {
        this.momento = momento;
    }    
}
