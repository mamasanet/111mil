/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.entidades;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class Cultivo {
 
    /* atributos */
    private int id;
    private String nombre;
    private List<LaboreoCultivo> laboreos;
    
    /* constructor*/
    public Cultivo(){}
    public Cultivo(String nombre){
        this.nombre= nombre;  
        this.laboreos = new ArrayList<>();
    }
    
     /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * @return the laboreos
     */
    public List<LaboreoCultivo> getLaboreos() {
        return laboreos;
    }

    /**
     * @param laboreos the laboreos to set
     */
    public void setLaboreos(List<LaboreoCultivo> laboreos) {
        this.laboreos = laboreos;
    }    
}
