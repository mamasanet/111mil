/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.controller;

import agro.dao.CamposDao;
import agro.dao.CamposDaoImplementacion;
import agro.dao.EstadosCampoDao;
import agro.dao.EstadosCampoDaoImplementacion;
import agro.dao.TiposSueloDao;
import agro.dao.TiposSueloDaoImplementacion;
import agro.entidades.Campo;
import agro.entidades.EstadoCampo;
import agro.entidades.Lote;
import agro.entidades.TipoSuelo;
import agro.ui.PantallaAgregarCampo;
import java.util.List;
import org.hibernate.SessionFactory;

/**
 *
 * @author María Isabel Masanet
 */
public class Gestor {
    private final CamposDao camposDao;
    private final EstadosCampoDao estadosCampoDao;
    private final TiposSueloDao tiposSueloDao;
    
    public Gestor(){
        this.estadosCampoDao = new EstadosCampoDaoImplementacion();
        this.tiposSueloDao = new TiposSueloDaoImplementacion();      
        this.camposDao = new CamposDaoImplementacion(); 
    }
    
    public Gestor(SessionFactory sessionFactory){       
        this.estadosCampoDao = new EstadosCampoDaoImplementacion(sessionFactory);
        this.tiposSueloDao = new TiposSueloDaoImplementacion(sessionFactory);      
        this.camposDao = new CamposDaoImplementacion(sessionFactory); 
    }    
    public void run () {
        new PantallaAgregarCampo(this).setVisible(true);
    }
    
    /** 
     * Crea un nuevo campo y lo guarda en la base de datos
     * @param nombre del campo
     * @param superficie total del campo
     * @param lotes es una lista con los lotes que conforman el campo
     * @param  estado el estado inicial del campo, que es "Creado"
     * @return la instancia creada de la clase Campo 
    **/
    
    public Campo CrearCampo(String nombre, float superficie, List<Lote> lotes, EstadoCampo estado){
        Campo nuevoCampo = new Campo(nombre, superficie, lotes, estado);
        camposDao.agregarCampoDB(nuevoCampo);
        return nuevoCampo;
    }
    
    // Métodos para Obtener datos
    
    /**
     * @return  lista con los números de suelo
     **/
    public List<String> getNumerosSuelo(){
        return tiposSueloDao.getNumerosSuelo();      
    }
    
    //Métodos de Búsquedas
    
   /** 
     * @param nombre del campo a buscar
     * @return el Campo que tiene el nombre pasado como parámetro, si no lo encuentra retorna null
     **/
    public Campo buscarCampoPorNombre(String nombre){
       return this.camposDao.buscarPorNombre(nombre);
    }
    
    public Campo buscarCampoPorNombreDB(String nombre){
        return this.camposDao.buscarPorNombreDB(nombre);
    }
    
     /** 
     * @param numero del tipo de suelo a buscar
     * @return el tipo de suelo que tiene el numero pasado como parámetro, si no lo encuentra retorna null
     **/
    public TipoSuelo buscarTipoSuelo(String numero){
        return this.tiposSueloDao.buscarPorNumero(numero);        
    }
    
    /** 
     * @param nombre del estado del campo a buscar
     * @return el estado del campo que tiene el nombre pasado como parámetro, si no lo encuentra retorna null
     **/
    public EstadoCampo buscarEstadoCampo(String nombre){
       return this.estadosCampoDao.buscarPorNombreDB(nombre);       
       
    }    
}
