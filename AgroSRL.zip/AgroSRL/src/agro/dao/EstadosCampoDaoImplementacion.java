/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.EstadoCampo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.swing.JOptionPane;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author María Isabel Masanet
 */
public class EstadosCampoDaoImplementacion implements EstadosCampoDao {
    private final SessionFactory sessionFactory ;
    private List<EstadoCampo> estadosCampo;
    
    //Constructor para probar sin Base de datos
    public EstadosCampoDaoImplementacion(){       
        this.estadosCampo = new ArrayList<>();
        this.estadosCampo.add(new EstadoCampo("Creado"));
        this.estadosCampo.add(new EstadoCampo("Parcialmente trabajado"));
        sessionFactory= null;
    }
     
    public EstadosCampoDaoImplementacion(SessionFactory sessionFactory){
        this.sessionFactory = sessionFactory;

        /*Session session = sessionFactory.openSession();        
        this.estadosCampo = session.createQuery("from estadocampo").list();
        session.close();        
        */
         try (Session session = this.sessionFactory.openSession()) {       
            session.beginTransaction();  
            CriteriaQuery<EstadoCampo> query = session.getCriteriaBuilder().createQuery(EstadoCampo.class);
            query.select(query.from(EstadoCampo.class));
            this.estadosCampo = session.createQuery(query).list();      
            session.getTransaction().commit();
            session.close();
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al leer los datos de Estado de Campo ", "Datos",JOptionPane.ERROR_MESSAGE);
            this.estadosCampo = null;
        }
    }
    
    
    @Override
    public EstadoCampo buscarPorNombre (String nombre){        
        EstadoCampo retorno = null;
        Boolean encuentra = false;
        
        Iterator<EstadoCampo> iter = estadosCampo.iterator();
        while (iter.hasNext() && !encuentra) {
            EstadoCampo estadoCampo = iter.next();
            
            if (estadoCampo.getNombre().equals(nombre)) {
                retorno = estadoCampo;
                encuentra = true;   
            }
        }
        return retorno;
    }  
    
    @Override
    public EstadoCampo buscarPorNombreDB (String nombre){        
        Session session = sessionFactory.openSession();
        
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<EstadoCampo> query = builder.createQuery(EstadoCampo.class);
        Root<EstadoCampo> root = query.from(EstadoCampo.class);
        query.select(root);
        query.where(builder.equal(root.get("nombre"), nombre));
        
        EstadoCampo estadoCampo = session.createQuery(query).uniqueResult();
        session.close();        
        return estadoCampo;
    }  
}
