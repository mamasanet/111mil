/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.EstadoProyecto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class EstadosProyectoDaoImplementacion implements EstadoProyectoDao {
    private final List<EstadoProyecto> estadosProyecto;
    
    public EstadosProyectoDaoImplementacion(){
        this.estadosProyecto = new ArrayList<>();
    }    
}
