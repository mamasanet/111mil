/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.Cultivo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public class CultivosDaoImplementacion implements CultivosDao {
    private final List<Cultivo> cultivos;
    
    public CultivosDaoImplementacion(){
        this.cultivos = new ArrayList<>();
    }
    
}
