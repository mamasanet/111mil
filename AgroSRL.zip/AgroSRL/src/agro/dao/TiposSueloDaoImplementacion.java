/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.TipoSuelo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.swing.JOptionPane;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author María Isabel Masanet
 */
public class TiposSueloDaoImplementacion implements TiposSueloDao {
    private final SessionFactory sessionFactory;
    private  List<TipoSuelo> tiposSuelo;
    
    //ESte constructor es para trabajar sin la base de datos
    public TiposSueloDaoImplementacion(){       
        this.tiposSuelo= new ArrayList<>();
        this.tiposSuelo.add(new TipoSuelo("I","Húmedo"));
        this.tiposSuelo.add(new TipoSuelo("II","Salino"));
        
        sessionFactory= null;
    }
    
    public TiposSueloDaoImplementacion(SessionFactory sessionFactory){    
        this.sessionFactory = sessionFactory;
        //Query query = session.createQuery("from tiposuelo");
        try (Session session = this.sessionFactory.openSession()) {       
            session.beginTransaction();  
            CriteriaQuery<TipoSuelo> query = session.getCriteriaBuilder().createQuery(TipoSuelo.class);
            query.select(query.from(TipoSuelo.class));
            this.tiposSuelo = session.createQuery(query).list();      
            session.getTransaction().commit();
            session.close();
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al leer los datos ", "Datos",JOptionPane.ERROR_MESSAGE);
            this.tiposSuelo = null;
        }        
      }
        
    /**
     * @return the tiposSuelo
     */
    public List<TipoSuelo> getTiposSuelo() {
        return tiposSuelo;
    }
    
    @Override
    public TipoSuelo buscarPorNumero (String numero){
        TipoSuelo retorno = null;
        Boolean encuentra = false;
        
        Iterator<TipoSuelo> iter = getTiposSuelo().iterator();
        while (iter.hasNext() && !encuentra) {
            TipoSuelo suelo = iter.next();
            
            if (suelo.getNumero().equals(numero)) {
                retorno = suelo;
                encuentra = true;   
            }
        }
        return retorno;
    }
    
    @Override
    public TipoSuelo buscarPorNumeroDB (String numero){
        Session session = sessionFactory.openSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<TipoSuelo> query = builder.createQuery(TipoSuelo.class);
        Root<TipoSuelo> root = query.from(TipoSuelo.class);
        query.select(root);        
        query.where(builder.equal(root.get("numero"), numero));        
        TipoSuelo tipoSuelo = session.createQuery(query).uniqueResult();        
        session.close();       
        
        return tipoSuelo;  
    }
    
    @Override
    public List<String> getNumerosSuelo(){
        List<String> numeros= new ArrayList<>();
        for(TipoSuelo tipo: tiposSuelo){
            numeros.add(tipo.getNumero());
        }
        return numeros;
    }    
}
