/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.TipoSuelo;
import java.util.List;

/**
 *
 * @author María Isabel Masanet
 */
public interface TiposSueloDao {
    public TipoSuelo buscarPorNumero (String numero);
    public TipoSuelo buscarPorNumeroDB (String numero);
    public List<String> getNumerosSuelo();
}
