/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.Campo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.swing.JOptionPane;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author María Isabel Masanet
 */
public class CamposDaoImplementacion implements CamposDao{
    private final SessionFactory sessionFactory;
    private List<Campo> campos;
    /**
     * Constructor para trabajar sin base de datos
     */
    public CamposDaoImplementacion(){
     this.sessionFactory= null;
     this.campos=new ArrayList<>();
     this.campos.add(new Campo("Paula",12,null,null));
    }
    
    /**
     * Constructor para trabajar con base de datos
     * @param un SessionFactory para acceder a la BD
     */
    public CamposDaoImplementacion(SessionFactory sessionFactory){   
        this.sessionFactory = sessionFactory;
        try (Session session = this.sessionFactory.openSession()) {       
            session.beginTransaction();  
            CriteriaQuery<Campo> query = session.getCriteriaBuilder().createQuery(Campo.class);
            query.select(query.from(Campo.class));
            this.campos = session.createQuery(query).list();      
            session.getTransaction().commit();
            session.close();        
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al leer los datos de los Campos ", "Datos",JOptionPane.ERROR_MESSAGE);
            this.campos = null;
        }        
    }
    
    /**
     * Agregar el campo parámetro a la lista de campos en memoria
     * @param campo 
     */
    @Override
    public void agregarCampo(Campo campo){
        this.campos.add(campo);
    }
    
     /**
     * Agrega el campo a la base de datos y a la lista en memoria
     * @param campo 
     */
    @Override
    public void agregarCampoDB(Campo campo){
        
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(campo);
        session.getTransaction().commit();
        // Actualiza la lista en memoria
        this.campos.add(campo);
        session.close();        
    }
    
    /**
     * 
     * @param nombre del campo a buscar
     * @return el campo que tiene el nombre del parametro
     */
     @Override
    public Campo buscarPorNombre (String nombre){
        Iterator<Campo> iter = this.campos.iterator();
        boolean esta= false;
        Campo retorno = null;
        
        while (!esta && iter.hasNext()){
            Campo c= iter.next();  
            if (c.getNombre().toUpperCase().equals(nombre.toUpperCase())){
                esta= true;       
                retorno = c;
            }   
        }
        return retorno;
    }
     
    /**
     * Busca un campo en la base de datos
     * @param nombre del campo a buscar
     * @return el campo que tiene el nombre del parametro
     */
    @Override
    public Campo buscarPorNombreDB (String nombre){        
        Session session = sessionFactory.openSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Campo> query = builder.createQuery(Campo.class);
        Root<Campo> root = query.from(Campo.class);
        query.select(root);        
        query.where(builder.equal(root.get("nombre"), nombre));        
        Campo campo = session.createQuery(query).uniqueResult();        
        session.close();       
        
        return campo;  
    }     
}