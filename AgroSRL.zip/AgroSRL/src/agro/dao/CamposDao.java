/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agro.dao;

import agro.entidades.Campo;

/**
 *
 * @author María Isabel Masanet
 */
public interface CamposDao {    
    public Campo buscarPorNombre(String nombre);  
    public void agregarCampo(Campo campo);    
    public Campo buscarPorNombreDB(String nombre);  
    public void agregarCampoDB(Campo campo);    
}
